import * as React from "react";
import {Button} from "antd";


const ${NAME} = ()=>{
  return (
    <div>
        ${NAME}
    </div>
  )
}
export default ${NAME}